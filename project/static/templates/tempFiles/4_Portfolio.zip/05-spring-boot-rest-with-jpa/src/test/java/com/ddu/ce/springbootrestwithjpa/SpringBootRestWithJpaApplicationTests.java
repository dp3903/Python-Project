package com.ddu.ce.springbootrestwithjpa;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class SpringBootRestWithJpaApplicationTests {

	@Test
	void contextLoads() {
	}

}
