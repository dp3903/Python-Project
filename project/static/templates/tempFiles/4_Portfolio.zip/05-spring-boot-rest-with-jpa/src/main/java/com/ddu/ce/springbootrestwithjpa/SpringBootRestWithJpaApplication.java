package com.ddu.ce.springbootrestwithjpa;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class SpringBootRestWithJpaApplication {

	public static void main(String[] args) {
		SpringApplication.run(SpringBootRestWithJpaApplication.class, args);
	}

}
